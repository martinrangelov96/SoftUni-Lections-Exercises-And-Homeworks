package app.entities.benders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AirBenderNation {

    private List<AirBender> airBenderNation;

    public AirBenderNation() {
        this.airBenderNation = new ArrayList<>();
    }

    public List<AirBender> getAirBenderNation() {
        return Collections.unmodifiableList(this.airBenderNation);
    }

    public double calculateTotalPower() {
        double totalPowerSum = 0.0;
        for (AirBender airBender : airBenderNation) {
            totalPowerSum += airBender.calculateTotalPower();
        }
        return totalPowerSum;
    }

//    public int increaseByMonumentBonus(int airAffinity) {
//        int totalFinalSum = 0;
//        for (AirBender airBender : airBenderNation) {
//
//        }
//    }
}
