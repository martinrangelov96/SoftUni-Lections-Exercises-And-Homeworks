package app.entities.benders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FireBenderNation {

    private List<FireBender> fireBenderNation;

    public FireBenderNation() {
        this.fireBenderNation = new ArrayList<>();
    }

    public List<FireBender> getFireBenderNation() {
        return Collections.unmodifiableList(this.fireBenderNation);
    }

    public double calculateTotalPower() {
        double totalPowerSum = 0.0;
        for (FireBender fireBender : fireBenderNation) {
            totalPowerSum += fireBender.calculateTotalPower();
        }
        return totalPowerSum;
    }
}
