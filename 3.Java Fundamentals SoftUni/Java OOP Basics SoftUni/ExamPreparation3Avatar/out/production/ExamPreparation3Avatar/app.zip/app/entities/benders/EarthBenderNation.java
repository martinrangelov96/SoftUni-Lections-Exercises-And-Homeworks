package app.entities.benders;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EarthBenderNation {

    private List<EarthBender> earthBenderNation;

    public EarthBenderNation() {
        this.earthBenderNation = new ArrayList<>();
    }

    public List<EarthBender> getEarthBanderNation() {
        return Collections.unmodifiableList(this.earthBenderNation);
    }

    public double calculateTotalPower() {
        double totalPowerSum = 0.0;
        for (EarthBender earthBender : earthBenderNation) {
            totalPowerSum += earthBender.calculateTotalPower();
        }
        return totalPowerSum;
    }

}
