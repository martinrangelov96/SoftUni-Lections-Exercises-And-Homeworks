package app.utilities;

public class Constants {
    private Constants() {
    }

    public static final String INPUT_TERMINATING_COMMAND = "Quit";
}
