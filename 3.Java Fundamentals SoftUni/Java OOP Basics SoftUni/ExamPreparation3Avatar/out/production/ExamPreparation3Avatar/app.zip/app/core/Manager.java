package app.core;

import app.entities.Nation;
import app.entities.benders.Bender;
import app.entities.monuments.Monument;
import app.factories.BenderFactory;
import app.factories.MonumentFactory;
import javafx.util.Pair;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Manager {

    private Map<String, List<Bender>> benders;
    private Map<String, List<Monument>> monuments;

    public Manager() {
        this.benders = new LinkedHashMap<>();
        this.monuments = new LinkedHashMap<>();
    }

    public void createBender(String type, String name, int power, double secondaryParameter) {
        if (!benders.containsKey(type)) {
            benders.put(type, new ArrayList<>());
        }
        benders.get(type).add(BenderFactory.createBender(type, name, power, secondaryParameter));

    }

    public void createMonument(String type, String name, int affinity) {
        if (!monuments.containsKey(type)) {
            monuments.put(type, new ArrayList<>());
        }
        monuments.get(type).add(MonumentFactory.createMonument(type, name, affinity));
    }

    public String getStatus(String nation) {

        String result = "";
        switch (nation) {
            case "Air":
                result += String.format("Air Nation%n");

                if (!benders.containsKey(nation)) {
                    result += String.format("Benders: None%n");
                } else {
                    result += String.format("Benders:%n");

                    for (Map.Entry<String, List<Bender>> entry : benders.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                if (!monuments.containsKey(nation)) {
                    result += String.format("Monuments: None%n");
                } else {

                    result += String.format("Monuments:%n");

                    for (Map.Entry<String, List<Monument>> entry : monuments.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                break;
            case "Water":
                result += String.format("Water Nation%n");

                if (!benders.containsKey(nation)) {
                    result += String.format("Benders: None%n");
                } else {
                    result += String.format("Benders:%n");

                    for (Map.Entry<String, List<Bender>> entry : benders.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                if (!monuments.containsKey(nation)) {
                    result += String.format("Monuments: None%n");
                } else {

                    result += String.format("Monuments:%n");

                    for (Map.Entry<String, List<Monument>> entry : monuments.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                break;
            case "Fire":
                result += String.format("Fire Nation%n");

                if (!benders.containsKey(nation)) {
                    result += String.format("Benders: None%n");
                } else {
                    result += String.format("Benders:%n");

                    for (Map.Entry<String, List<Bender>> entry : benders.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                if (!monuments.containsKey(nation)) {
                    result += String.format("Monuments: None%n");
                } else {

                    result += String.format("Monuments:%n");

                    for (Map.Entry<String, List<Monument>> entry : monuments.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                break;
            case "Earth":
                result += String.format("Earth Nation%n");

                if (!benders.containsKey(nation)) {
                    result += String.format("Benders: None%n");
                } else {
                    result += String.format("Benders:%n");

                    for (Map.Entry<String, List<Bender>> entry : benders.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                if (!monuments.containsKey(nation)) {
                    result += String.format("Monuments: None%n");
                } else {

                    result += String.format("Monuments:%n");

                    for (Map.Entry<String, List<Monument>> entry : monuments.entrySet()) {
                        if (entry.getKey().equals(nation)) {
                            for (int i = 0; i < entry.getValue().size(); i++) {
                                result += String.format("%s%n", entry.getValue().get(i));
                            }
                        }
                    }
                }
                break;
        }
        return result;
    }
}
