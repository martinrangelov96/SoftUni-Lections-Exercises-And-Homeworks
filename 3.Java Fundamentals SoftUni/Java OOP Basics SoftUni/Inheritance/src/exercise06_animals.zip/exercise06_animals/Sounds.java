package exercise06_animals;

public class Sounds {

    public void produceSound() {

    }

}
