package exercise04_pizzaCalories;

public final class PizzaConstants {

    public static final double BASE_CALORIES = 2;

    private PizzaConstants() {}
}
