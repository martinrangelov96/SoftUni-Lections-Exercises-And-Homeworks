package app.utils;

public final class Constants {
    public static final String TERMINAL_COMMAND = "BEER IS COMING";

    private Constants(){}

    public static final String EMPTY_STRING = "";
}
