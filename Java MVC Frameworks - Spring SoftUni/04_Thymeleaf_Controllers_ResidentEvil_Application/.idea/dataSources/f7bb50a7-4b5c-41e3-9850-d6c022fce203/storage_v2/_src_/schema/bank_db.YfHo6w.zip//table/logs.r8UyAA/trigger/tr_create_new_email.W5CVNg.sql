create definer = root@localhost trigger tr_create_new_email
    after INSERT
    on logs
    for each row
BEGIN
	INSERT INTO `notification_emails`
		(`recipient`, `subject`, `body`)
	VALUES
		(NEW.`account_id`, CONCAT_WS(' ', 'Balance change for account:', NEW.`account_id`),
        CONCAT_WS(' ', 'On', DATE_FORMAT(NOW(), '%b %d %Y at %r'), 'your balance was changed from',
        NEW.`old_sum`, 'to', NEW.`new_sum`,'.'));
END;

