create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN account_id int, IN yearly_interest_rate decimal(13, 4))
BEGIN
	SELECT 
		a.`account_holder_id`,
		ah.`first_name`,
        ah.`last_name` AS `current_balance`,
        a.`balance`,
        `ufn_calculate_future_value`(a.`balance`, `yearly_interest_rate`, 5) AS `balance_in_5_years`
	FROM `accounts` a
	INNER JOIN `account_holders` ah
		ON a.`account_holder_id` = ah.`id`;
END;

