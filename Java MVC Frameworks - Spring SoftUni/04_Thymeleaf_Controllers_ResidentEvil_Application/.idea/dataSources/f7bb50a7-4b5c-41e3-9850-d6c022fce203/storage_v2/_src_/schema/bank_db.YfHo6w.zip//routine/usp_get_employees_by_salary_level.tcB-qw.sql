create
    definer = root@localhost procedure usp_get_employees_by_salary_level(IN employee_salary varchar(10))
BEGIN
	DECLARE `salary_min` DECIMAL (13,4);
    DECLARE `salary_max` DECIMAL (13,4);
    IF `employee_salary` = 'Low' THEN
		SET `salary_min` = 0;
		SET `salary_max` = 30000;
    ELSEIF `employee_salary` = 'Average' THEN
		SET `salary_min` = 29999.9999;
        SET `salary_max` = 50000.0001;
	ELSEIF `employee_salary` = 'High' THEN
		SET `salary_min` = 50000;
        SET `salary_max` = 999999999;
	END IF;
    
    SELECT
		e.`first_name`,
        e.`last_name`
	FROM `employees` e
		WHERE e.`salary` > `salary_min` AND e.`salary` < `salary_max`
	ORDER BY 
		e.`first_name` DESC,
        e.`last_name` DESC;
END;

