create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN balance_number double)
BEGIN
	SELECT
		ah.`first_name`,
        ah.`last_name`
	FROM `account_holders` ah
	INNER JOIN `accounts` a
		ON ah.`id` = a.`account_holder_id`
	GROUP BY ah.`id`
		HAVING SUM(a.`balance`) > `balance_number`
	ORDER BY
		a.`id`,
        ah.`first_name` DESC,
        ah.`last_name`;
END;

