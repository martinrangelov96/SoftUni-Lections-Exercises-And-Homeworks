create
    definer = root@localhost function ufn_calculate_future_value(initial_sum decimal(13, 4),
                                                                 yearly_interest_rate decimal(13, 4),
                                                                 number_of_years decimal(13, 4)) returns decimal(13, 4)
BEGIN
	DECLARE `future_value` DECIMAL (13,4);
    SET `future_value` := `initial_sum` * POW(1+`yearly_interest_rate`, `number_of_years`) *100/100;
    RETURN `future_value`;
END;

