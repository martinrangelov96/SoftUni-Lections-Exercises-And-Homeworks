create
    definer = root@localhost procedure udp_submit_review(IN customer_id int, IN review_content varchar(255),
                                                         IN review_grade int, IN airline_name varchar(30))
BEGIN
	DECLARE `airline_name` VARCHAR(30);
    
    IF 1 <> (SELECT COUNT(*) FROM `airlines` a WHERE a.`airline_name` = `airline_name`)
	THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Airline does not exist';
    END IF;
    
    SET `airline_name` := (
		SELECT a.`airline_name`
        FROM `airlines` a
			WHERE a.`airline_name` = `airline_name`
    );
    
    INSERT INTO `customer_reviews`(`customer_id`, `review_content`, `review_grade`, `airline_id`)
    VALUES (`customer_id`, `review_content`, `review_grade`, `airline_id`);
END;

